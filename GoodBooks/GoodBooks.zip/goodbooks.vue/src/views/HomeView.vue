<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/GoodBooksLogo.png">
  </div>
</template>

<script lang="ts">
import { Options, Vue } from 'vue-class-component';

@Options({
  components: {},
})
export default class HomeView extends Vue {}
</script>
