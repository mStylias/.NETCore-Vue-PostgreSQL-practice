export default interface IBook {
    id: number
    createdOn: Date
    updatedOn: Date
    title: string
    author: string
}