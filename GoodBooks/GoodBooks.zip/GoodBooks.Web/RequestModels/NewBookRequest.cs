namespace GoodBooks.Web.RequestModels;

public class NewBookRequest
{
    public string Title { get; set; }
    public string Author { get; set; }
}